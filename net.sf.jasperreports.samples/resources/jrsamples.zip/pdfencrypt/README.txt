You might want to play with the "Exporter Parameters" in order to test correctly how to produce an encrypted PDF.
Look at the "encryptionConfigSample.png" file to have an overview.